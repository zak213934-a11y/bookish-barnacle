Anime Prompt Generator Genv3 (v6.5.1) + Pro GUI

Run (recommended):
  python anime_prompt_generator_gui_pro.py

Alternative (simple):
  python anime_prompt_generator_gui_plus.py

Notes:
- Data folder is ./data by default.
- GUI 'Reload' can point to any data folder.
- Audit shows Found vs Used vs Unused .txt files.
- Auto-append adds tags from UNUSED files (optional).
